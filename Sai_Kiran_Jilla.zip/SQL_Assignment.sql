create database SQL_Assignment;

use SQL_Assignment;

create table Customer(
Id int primary key,
FirstName nvarchar(40) not null,
LastName nvarchar(40),
City nvarchar(40),
Country nvarchar(40),
Phone nvarchar(20)
);

create index IndexCustomerName on Customer(FirstName);

select * from Customer where FirstName='Pavan';

sp_helpindex Customer;

create table [Order](
Id int primary key,OrderDate datetime not null,OrderNumber nvarchar(10),CustomerId int,TotalAmount decimal(12,2)
);

create index IndexOrderCustomerId on [Order](CustomerId);
create index IndexOrderOrderDate on [order](OrderDate);

sp_helpindex [Order];

create table OrderItem(
Id int primary key,
OrderId int,
ProductId int,
UnitPrice decimal(12,2),
Quantity int
);

create index IndexOrderItemOrderId on OrderItem(OrderId);
create index IndexOrderItemProductId on OrderItem(ProductId);


sp_helpindex OrderItem;

create table Product(
Id int primary key,
ProductName nvarchar(50),
UnitPrice decimal(12,2),
Package nvarchar(30),
IsDiscontinued bit
);

create index IndexProductSupplierId on Product(Id);
create nonclustered index IndexProductName on Product(ProductName);


sp_helpindex Product;

insert into Customer values(
3,'Varun','Kumar','London','United Kingdom','+918106831800'),
(4,'Kalyan','Reddy','Mumbai','India','+917799567790'
);

select * from Customer;

insert into [Order] values(
45,2021-04-10,'od123',1,1029),
(56,2021-07-04,'od367',2,999),
(78,2021-09-02,'od562',3,1999),
(34,2021-07-01,'od467',3,2449);

select * from [order];

insert into OrderItem values(
22,45,345,540,10),
(12,56,678,567.50,5),
(15,78,155,454.75,12),
(7,45,222,567.50,5),
(2,34,333,120,20);

select * from OrderItem;

insert into Product values(
345,'Boost',120,'mug',0),
(678,'Horlicks',100,'package',1),
(222,'Bournvita',80,'mug',1),
(333,'Bru',10,'sachet',1);

select * from Product;

alter table [Order] add constraint FK_Order_Customer foreign key(CustomerId) references Customer(Id);

alter table OrderItem add foreign key(OrderId) references [Order](Id),foreign key(ProductId) references Product(Id);

select * from OrderItem;

alter table OrderItem add constraint FK_OrderItem_Order foreign key(OrderId) references [Order](Id);
alter table OrderItem add constraint FK_OrderItem_Product foreign key(ProductId) references Product(Id);

select * from Customer;

select Country from Customer where country like '[AI]%';

select FirstName from Customer where FirstName like '__i%';

insert into Customer values(7,'Sharath','Chandra','berlin','Germany');

select * from Customer;

select * from Customer where Country='Germany';

select concat(FirstName,LastName) as fullname from Customer;

alter table Customer add FaxNumber int;

update Customer set FaxNumber=34234 where id =2 ;

select * from Customer where FaxNumber is not null;

insert into Customer values(12,'Sushma','Sharma','Kolar','India','+919553043041',453534);

select * from Customer where FirstName like '_u%';

select * from OrderItem where UnitPrice>10 and UnitPrice<20;

alter table [order] add ShippingDate datetime;

update [Order] set ShippingDate=2021-05-10 where Id=45;
update [Order] set ShippingDate=2021-05-10 where Id=78;
update [Order] set ShippingDate=2021-05-01 where Id=34;


select * from [Order] order by OrderDate desc;

alter table [order] add ShipName nvarchar(40);

update [Order] set ShipName='La corne d''abondance' where Id=45;
update [Order] set ShipName='La corne d''abondance' where Id=78;
update [Order] set ShipName='power electronics' where Id=34;


select * from [Order] where ShipName='La corne d''abondance';


alter table Product add SupplierName nvarchar(40);

update Product set SupplierName='Exotic Liquids' where id in(222,345);
update Product set SupplierName='Abc' where id in(333,678);

select ProductName from Product where SupplierName='Exotic Liquids';

select ProductId,avg(Quantity) from OrderItem group by(ProductId);

select distinct ShipName from [Order];

select * from Employee;

select E.Name as Employee,M.Name as Manager from Employee E join Employee M on E.Id=M.Id;

CREATE TABLE EMPLOYEE2
(
ID INT,
NAME Varchar(100),
DEPARTMENT INT,
EMAIL Varchar(100)
)

INSERT INTO EMPLOYEE2 VALUES (1,'Tarun',101,'tarun@intellipaat.com')
INSERT INTO EMPLOYEE2 VALUES (2,'Sabid',102,'sabid@intellipaat.com')
INSERT INTO EMPLOYEE2 VALUES (3,'Adarsh',103,'adarsh@intellipaat.com')
INSERT INTO EMPLOYEE2 VALUES (4,'Vaibhav',104,'vaibhav@intellipaat.com')

select * from employee2;

INSERT INTO EMPLOYEE2 VALUES (5,'Tarun',101,'tarun@intellipaat.com')
INSERT INTO EMPLOYEE2 VALUES (6,'Sabid',102,'sabid@intellipaat.com')